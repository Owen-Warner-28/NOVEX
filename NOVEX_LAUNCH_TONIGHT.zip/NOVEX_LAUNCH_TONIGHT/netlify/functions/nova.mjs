const allowed = ['ad-copy','social-calendar','landing-page','email-sequence'];
const maxChars = 2500;
export default async (request) => {
  if (request.method !== 'POST') return Response.json({error:'Method not allowed'},{status:405});
  const admin = process.env.NOVEX_ADMIN_SECRET;
  const gemini = process.env.GEMINI_API_KEY;
  if (!admin || !gemini) return Response.json({error:'Owner AI not configured yet'},{status:503});
  if (request.headers.get('x-novex-admin') !== admin) return Response.json({error:'Unauthorized'},{status:401});
  let data;
  try { data = await request.json(); } catch {return Response.json({error:'Invalid JSON'},{status:400});}
  const {service,brief} = data || {};
  if (!allowed.includes(service) || typeof brief !== 'string' || brief.length < 15 || brief.length > maxChars) return Response.json({error:'Select a service and provide a 15–2500 character brief'},{status:400});
  const prompt = `You are NØVA, a digital services production assistant. Produce a polished, useful DRAFT for ${service}. Client brief: ${brief}. Avoid fabricated claims, testimonials, prices, research findings or performance guarantees. Label assumptions. Do not claim anything was posted, sent or purchased. Output clear headings, ready-to-review content and a short approval checklist.`;
  const controller = new AbortController();
  const timeout = setTimeout(()=>controller.abort(),25000);
  try {
    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent',{
      method:'POST',signal:controller.signal,headers:{'Content-Type':'application/json','x-goog-api-key':gemini},
      body:JSON.stringify({contents:[{role:'user',parts:[{text:prompt}]}],generationConfig:{maxOutputTokens:1700,temperature:0.6}})
    });
    const json = await response.json();
    if(!response.ok) return Response.json({error:response.status===429?'Free quota reached. No paid fallback.':'AI request failed. Check key and free-tier access.'},{status:response.status===429?429:502});
    const output = json.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('\n') || '';
    if(!output) return Response.json({error:'AI returned no text'},{status:502});
    return Response.json({draft:output,approved:false});
  } catch {return Response.json({error:'AI timed out or network failed'},{status:504});}
  finally {clearTimeout(timeout);}
};
