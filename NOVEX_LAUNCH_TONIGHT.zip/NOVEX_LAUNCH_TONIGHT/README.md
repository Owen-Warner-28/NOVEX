# NØVEX — Launch Tonight

This is a deployable **public lead-generation website** with a Netlify Forms order/quote request intake and a protected owner-only Gemini draft generator. No customer accounts, payment collection, or automatic delivery yet. Prices are starting estimates, not automatic charges.

## Deploy without npm (Chromebook-friendly)

1. Download this ZIP, open Chromebook **Files**, and copy it from **Downloads** into **Linux files**.
2. Extract with `cd ~ && unzip -o NOVEX_LAUNCH_TONIGHT.zip` (or unzip through Files). It contains a `NOVEX_LAUNCH_TONIGHT` folder.
3. Create a free GitHub repository at https://github.com/new (private recommended). Upload **the contents** of the `NOVEX_LAUNCH_TONIGHT` folder, including `netlify.toml`, `public/`, and `netlify/`. GitHub web upload may require selecting files in each folder; using Git locally is easier:
   ```bash
   cd ~/NOVEX_LAUNCH_TONIGHT
   git init
   git add .
   git commit -m 'Launch NØVEX'
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
   GitHub authentication is required for push. Alternatively upload using the GitHub website.
4. At https://app.netlify.com/start select **Import from Git**, choose your repo. Netlify reads `netlify.toml` (publish `public`, functions `netlify/functions`). Deploy.
5. In Netlify project **Forms**, enable form detection if prompted, then **redeploy**. Submit a test request on your live website and check Netlify Forms submissions. Add email notifications for new submissions in Netlify settings if desired. Forms free-tier limits apply.
6. In Netlify **Environment variables**, set `GEMINI_API_KEY` (from https://aistudio.google.com/apikey) and `NOVEX_ADMIN_SECRET` (a unique long random secret). Set variables for Functions and redeploy. Do not commit keys or put them in client-side JS. Keep Google AI Studio project **Free tier** and don't enable paid billing.
7. Open `https://YOUR-SITE.netlify.app/owner.html` and enter your owner secret to create drafts. **Owner page URL is public** but AI endpoint requires the secret; do not share it. For stronger security before scaling, add Netlify Identity or Supabase auth and persistent rate limiting. Current endpoint does not provide durable request rate limiting; free-tier quotas and no billing are the spending boundary.
8. Edit the placeholder footer contact email `hello@example.com` in `public/index.html` to your real business contact address **before launch**. Replace starter prices with your actual quoted prices, review all marketing copy, and add privacy policy/terms appropriate for collecting customer information.

## Security and limits
- Public forms accept quote requests, **not payments**. Review spam and form quotas in Netlify.
- Gemini function requires `x-novex-admin` secret and validates service and input length. Draft-only, never publishes or spends on ads.
- Owner secret is held in the owner page's input during the session, not stored in localStorage. Use a long random secret, do not share browser screen while entering it.
- This is a useful live website + owner AI workflow, **not** a complete multi-user SaaS. No persistent job queue, no account logins, no automated delivery or Stripe payments.
- Never use a paid Gemini project if you need zero AI charges. Free-tier quotas can change; on exhaustion generation fails rather than switching models/providers.

## Test locally
You can preview the public website with `python3 -m http.server 8080 --directory public` and visit http://localhost:8080 . Netlify Forms and Functions only work when deployed on Netlify or under `netlify dev` with the Netlify CLI.

## Official links
- https://github.com/new
- https://app.netlify.com/start
- https://aistudio.google.com/apikey
- https://docs.netlify.com/manage/forms/setup/
- https://docs.netlify.com/build/functions/overview/
